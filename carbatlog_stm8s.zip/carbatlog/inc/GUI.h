#ifndef GUI_H_
#define GUI_H_

		
	void Receive(void);
	void DisplayData(void);
	void UART_print(char *string);


#endif /* GUI_H_ */
