
#include "stm8s.h"
#include "main.h"




#define SEND_DATA 0x34 // send  data
#define SEND_LOG 0x35  // send log data
#define SEND_LOGM 0x36  // send log data



uint8_t 	seconds=0,minutes=0,hours=0;
uint8_t 	Vbat10 =0,VbatMax =0,VbatMin =255;

extern unsigned char RXByte;		// Value received once hasReceived is set
//unsigned char Vbat10,VbatMax,VbatMin;
unsigned char logfull=0,logmfull=0,count=0,countm=0;
extern unsigned char hasReceived;			        // Lets the program know when a byte is received



void Create_Frame(void);
void Send_Frame(void);
void UART_print(char *string);
void Receive(void);
void UART_Txbyte(unsigned char txbyte);
void DisplayLog(void);
void DisplayLogM(void);



int size;
unsigned char FrameToSend[8];
@near extern unsigned char BatLog[240],BatLogm[240];




void Create_Frame(void)
{

	FrameToSend[0]= '*'; // header
	FrameToSend[1] =	Vbat10;
	FrameToSend[2] = VbatMax;
	FrameToSend[3] = VbatMin;
	FrameToSend[4]= seconds;
	FrameToSend[5]=	minutes;
	FrameToSend[6]=	hours;
	FrameToSend[7]='#'; // footer
}


void Send_Frame(void)
{
	int i;
	for(i=0;i<=7;i++)
		{
		     /* Write one byte to the transmit data register */
			UART1->DR = FrameToSend[i];
					 /* Wait until end of transmit */
			while ((UART1->SR & 0x80)== RESET)
			{
			}
		}
}


void DisplayData(void)
{
	Create_Frame();
	Send_Frame();
	
}




void UART_print(char *string)
{
    while (*string) {
			UART1->DR = *string++ ;
					 /* Wait until end of transmit */
			while ((UART1->SR & 0x80)== RESET);
    }
}


/**
 * Handles the received byte and calls the needed functions.\
 **/
void Receive(void)
{
	if (hasReceived != 0) {
		hasReceived = 0;	// Clear the flag 
		switch(RXByte)			// Switch depending on command value received
		{

			case SEND_DATA:
					DisplayData();
					break;
			
			case SEND_LOG:
					DisplayData();
					delay_ms(1000);
					DisplayLog();
					break;
					
			case SEND_LOGM:
					DisplayData();
					delay_ms(1000);
					DisplayLogM();
					break;		

			default:;
		}


	}

}

void UART_Txbyte(unsigned char txbyte)
{
			UART1->DR = txbyte ;
					 /* Wait until end of transmit */
			while ((UART1->SR & 0x80)== RESET);
}


void DisplayLog(void)
{
	unsigned char i;
	unsigned char maxcnt;
	unsigned char index;

	UART_Txbyte(0x2B);
	
	maxcnt=count;
	index=0;

	if (logfull==1) {
		maxcnt = 240;
		index = count; // buffer pointer 
	}
	for(i=0; i < maxcnt; i++)
		{
			UART_Txbyte(BatLog[index]);
			
			if (++index >= 240) index=0;
		}
	UART_Txbyte(0xFF);
}

void DisplayLogM(void)
{
	unsigned char i;
	unsigned char maxcnt;
	unsigned char index;

	UART_Txbyte(0x2C);
	
	maxcnt=countm;
	index=0;

	if (logmfull==1) {
		maxcnt = 240;
		index = countm; // buffer pointer 
	}
	for(i=0; i < maxcnt; i++)
		{
			UART_Txbyte(BatLogm[index]);
			
			if (++index >= 240) index=0;
		}
	UART_Txbyte(0xFF);
}
 

void ClockUpdate(void)
{
	if (++seconds > 59 ){
		seconds=0;
		
		if (++minutes > 59){
				minutes=0;
				if (++hours >= 24){
		    	 hours = 0;
				}
		}
	} 
}



void secondInt(void)
{

	ClockUpdate();
 
}










